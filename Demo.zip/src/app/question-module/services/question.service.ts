import { Injectable } from '@angular/core';
import "rxjs/add/observable/of";
import { Observable } from 'rxjs/Observable';
import { map } from "rxjs/operators";
import { dynamicJSON } from '../constants/multi-step-form';
@Injectable()
export class QuestionService {
    public data: any = [];
    public result: any = [];
    subscription: any = null;
    constructor() {}

    // Get question list
    getQuestion(): Observable<any> {
      this.data = dynamicJSON;
      this.data.map((item,i)=>{
      this.result
            .push({ 'label': item.key,
                    'data':{[`${item.key}`]: { 'type': item.type, 'options':item.options?item.options:[], 'validations':  { required: item.required},
                    'errors': {},
                    'placeholder': item.label }
                    }});

          if(dynamicJSON.length-1 == i)
          {   
          this.result
          .push({ 'label': 'address',
                  'data':{['address']: { 'type': 'address', 'options':[], 'validations':  { required: true},
                  'errors': {},
                  'placeholder': 'Choose Address' }
                  }}); 
          this.result.push({label: 'Review & Submit', data: {}});
          }
    });
      return Observable.of(this.result);
  }
}
