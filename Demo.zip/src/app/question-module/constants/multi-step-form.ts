// Constant json
 export const dynamicJSON = [
  {
      "key": "task_date",
      "label": "When do you want ?",
      "type": "calender",
      "value": "",
      "required": true,
      "order": 1
  },
  {
    "key": "timepreference",
    "label": "What time of day do you prefer?",
    "type": "radio",
    "options":[{
      "value":"Early Morning (before 9am)",
      "label":"Early Morning (before 9am)"
    },
    {
      "value":"Morning (9am - 12pm)",
      "label":"Morning (9am - 12pm)"
      },
      {
        "value":"Afternoon (12pm - 3pm)",
        "label":"Afternoon (12pm - 3pm)"
      },
      {
        "value":"Late Afternoon (3pm - 6pm)",
        "label":"Late Afternoon (3pm - 6pm)"
      },
      {
        "value":"Evening (after 6pm)",
        "label":"Evening (after 6pm)"
      }
    ],
    "required": true,
    "order": 5
  },
  {
      "key": "bathrooms",
      "label": "How many bathrooms ?",
      "type": "radio",
      "options":[{
        "value":"1 bathrooms",
        "label":"1 bathrooms"
       },
       {
         "value":"2 bathrooms",
         "label":"2 bathrooms"
        },
        {
          "value":"3 bathrooms",
          "label":"3 bathrooms"
        },
        {
          "value":"4 bathrooms",
          "label":"4 bathrooms"
        }],
      "required": true,
      "order": 2
  },
  {
    "key": "cleaning",
    "label": "What kind of cleaning do you need?",
    "type": "radio",
    "options":[{
      "value":"Deep cleaning",
      "label":"Deep cleaning"
     },
     {
       "value":"Standard cleaning",
       "label":"Standard cleaning"
      },
      {
        "value":"Move out cleaning",
        "label":"Move out cleaning"
      }
    ],
    "required": true,
    "order": 3
  },
  {
    "key": "extracleaning",
    "label": "Do you need any extras?",
    "type": "checkbox",
    "options":[{
      "value":"Window cleaning (Interior)",
      "label":"Window cleaning (Interior)"
    },
    {
      "value":"Fridge cleaning",
      "label":"Fridge cleaning"
      },
      {
        "value":"Ovan cleaning",
        "label":"Ovan cleaning"
      }
    ],
    "required": true,
    "order": 4
  }
];
