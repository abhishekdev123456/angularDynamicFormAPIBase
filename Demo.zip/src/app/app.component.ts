import { CommonService } from './shared/services/common.servie';
import { Component, OnInit } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { QuestionService } from './question-module/services/question.service';
import * as _ from 'lodash';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent implements OnInit  {
  title = 'demo';
  showAddressComponent: boolean = false;

  public display: boolean = false;
  public success: boolean = false;
  result:any = [];
  formContent: any;
  formData: any;
  activeStepIndex: number;
  constructor(private commonService: CommonService, private confirmationService: ConfirmationService, private quesSvc: QuestionService) {}
  ngOnInit(): void {
    this.quesSvc.getQuestion().subscribe((res)=>{
      this.formContent = res;
      this.formData = {};
    });

  }

  onFormSubmit(data:any): void {
    this.display = false;
    this.formData = data.formData;
    _.assign(this.formData, data.dump);
   // post form data here
   let d = JSON.parse(localStorage.getItem('data'))||[];
   d.push(this.formData);
   localStorage.setItem('data', JSON.stringify(d));

   this.success = true;
  //  alert(JSON.stringify(this.formData));
  }

  showDialog() {
    this.display = true;
  }

  close(event){
    let p = localStorage.getItem('progress');
    this.confirmationService.confirm({
      message: `Don't stop now. You are ${p}% done
      with your request.`,
      accept: () => {
        this.display = false;
      }
  });
  }
}

