import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AddressComponent } from './shared/component/address/address.component';
import { AgmCoreModule } from '@agm/core'
import { GooglePlaceModule } from "ngx-google-places-autocomplete"

import { CommonService } from './shared/services/common.servie';
import { MapComponent } from './shared/component/map/map.component';
import { HttpClientModule } from '@angular/common/http';
import { AddressCardComponent } from './shared/component/address-card/address-card';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MultiStepFormComponent } from './question-module/component/multi-step-form/multi-step-form.component';
import { trimStringPipe } from './question-module/pipes/trim.pipe';


//Primeng Controls
import { DialogModule } from 'primeng/dialog';
import { ButtonModule } from 'primeng/button';
import { CalendarModule } from 'primeng/calendar';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { QuestionService } from './question-module/services/question.service';

@NgModule({
  declarations: [
    AppComponent,
    AddressComponent,
    MapComponent,
    AddressCardComponent,
    MultiStepFormComponent,
    trimStringPipe
  ],
  imports: [
    GooglePlaceModule,
    BrowserModule,
    FormsModule,
    CommonModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    DialogModule,
    ButtonModule,
    CalendarModule,
    ConfirmDialogModule,
    AgmCoreModule.forRoot({
      // apiKey: 'AIzaSyAvcDy5ZYc2ujCS6TTtI3RYX5QmuoV8Ffw'
      apiKey: 'AIzaSyARR7uFPjj5hVSlCnTgYiq0VnfG2qM8d_A'
    })
  ],
  providers: [CommonService, QuestionService, ConfirmationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
